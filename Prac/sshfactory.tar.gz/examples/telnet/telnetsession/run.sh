#!/bin/sh
javac -classpath .:../../../lib/sshfactory.jar -d . TelnetSessionExample.java
java -cp .:../../../lib/sshfactory.jar TelnetSessionExample
