#!/bin/sh
java -jar ../../../lib/sshfactory.jar -f sshdirlisting.txt
