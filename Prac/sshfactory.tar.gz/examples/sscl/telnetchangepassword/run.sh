#!/bin/sh
java -jar ../../../lib/sshfactory.jar -f telnetchangepassword.txt
