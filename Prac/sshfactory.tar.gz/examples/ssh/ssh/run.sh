#!/bin/sh
javac -classpath .:../../../lib/sshfactory.jar -d . SshExample.java
java -cp .:../../../lib/sshfactory.jar SshExample
