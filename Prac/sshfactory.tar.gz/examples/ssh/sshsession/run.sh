#!/bin/sh
javac -classpath .:../../../lib/sshfactory.jar -d . SshSessionExample.java
java -cp .:../../../lib/sshfactory.jar SshSessionExample
