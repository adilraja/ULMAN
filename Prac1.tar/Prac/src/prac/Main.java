/*
 * Main.java
 *
 * Created on April 11, 2005, 4:53 PM
 */

package prac;

/**
 *
 * @author Administrator
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
        
    }
    
    /**
     * @param args the command line arguments
     */
 //   public static void main(String[] args) {
   //     // TODO code application logic here
     //   NewJFrame jf = new NewJFrame();
//    }
    
}
